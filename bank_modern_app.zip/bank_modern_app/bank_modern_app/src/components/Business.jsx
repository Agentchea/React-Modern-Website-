import React from 'react'

const Business = () => {
  return (
    <div>Business</div>
  )
}

export default Business