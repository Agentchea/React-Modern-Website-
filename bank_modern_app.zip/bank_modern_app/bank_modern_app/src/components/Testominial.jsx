import React from 'react'

const Testominial = () => {
  return (
    <div>Testominial</div>
  )
}

export default Testominial