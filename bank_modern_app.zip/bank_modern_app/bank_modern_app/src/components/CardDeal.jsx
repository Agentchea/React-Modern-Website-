import React from 'react'

const CardDeal = () => {
  return (
    <div>CardDeal</div>
  )
}

export default CardDeal