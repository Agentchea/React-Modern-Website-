import React from 'react'

const FeedbackCard = () => {
  return (
    <div>FeedbackCard</div>
  )
}

export default FeedbackCard