import React from 'react'

const CTA = () => {
  return (
    <div>CTA</div>
  )
}

export default CTA